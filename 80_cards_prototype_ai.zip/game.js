// 80 Cards Prototype
// Prototype deck: 10 card types x 8 copies.
// This intentionally differs from the eventual 80 unique-card rule.

const CARD_DEFS = [
  { id:"basic_attack", name:"基本攻撃", text:"コストなし / 6ダメージ", type:"attack", damage:6 },
  { id:"strong_attack", name:"強攻撃", text:"手札1枚を公開除外 / 9ダメージ", type:"attack", damage:9, exileCost:1 },
  { id:"basic_defense", name:"基本防御", text:"5防御", type:"defense", defense:5 },
  { id:"strong_defense", name:"強防御", text:"手札1枚を公開除外 / 8防御", type:"defense", defense:8, exileCost:1 },
  { id:"dodge", name:"回避", text:"2ライフ支払い / 受けるダメージを半減（切上げ）", type:"reaction", dodge:true },
  { id:"hand_reaction", name:"手札反応", text:"手札2枚を公開除外 / 相手に3ダメージ", type:"reaction", handCost:2, damage:3 },
  { id:"counterattack", name:"反撃", text:"手札2枚を公開除外 / このターン相手がカードを使うたび3ダメージ", type:"reaction", handCost:2, counter:true },
  { id:"draw", name:"ドロー", text:"このカードを公開除外 / 2枚引く", type:"utility", draw:2 },
  { id:"life_reuse", name:"命の再利用", text:"4ライフ / このカードを公開除外 / 公開除外から1枚を手札へ", type:"utility", reuse:true },
  { id:"reconstruct", name:"再構築", text:"山札10枚以下 / このカードを公開除外 / 墓地＋山札を再構築", type:"utility", reconstruct:true }
];

let state;

function makeDeck() {
  const deck = [];
  for (const c of CARD_DEFS) {
    for (let i=0; i<8; i++) {
      deck.push({ ...c, uid:`${c.id}_${i+1}` });
    }
  }
  return shuffle(deck);
}

function shuffle(a) {
  a = [...a];
  for (let i=a.length-1;i>0;i--) {
    const j=Math.floor(Math.random()*(i+1));
    [a[i],a[j]]=[a[j],a[i]];
  }
  return a;
}

function log(msg) {
  const el=document.querySelector("#log");
  el.textContent = msg + "\n" + el.textContent;
}

function draw(player,n) {
  for(let i=0;i<n;i++) {
    if(player.deck.length===0) rebuild(player);
    if(player.deck.length===0) break;
    player.hand.push(player.deck.pop());
  }
}

function rebuild(player) {
  if(player.grave.length===0) return;
  player.deck = shuffle(player.grave.splice(0));
  player.rebuilds++;
  player.life -= player.rebuilds;
  log(`${player.name} の山札を再構築。${player.rebuilds}回目なので ${player.rebuilds}ダメージ。`);
}

function publicExile(player, card) {
  const i=player.hand.indexOf(card);
  if(i>=0) player.hand.splice(i,1);
  player.publicExile.push(card);
}

function randomTrim(player) {
  while(player.hand.length>8) {
    const i=Math.floor(Math.random()*player.hand.length);
    const [card]=player.hand.splice(i,1);
    player.hiddenExile.push(card);
    log(`${player.name} の手札が8枚を超えたため、1枚をランダム除外。`);
  }
}

function startTurn(player) {
  randomTrim(player);
  if(player.hand.length<8) draw(player,8-player.hand.length);

  // Prototype compression: player chooses via a simple AI for AI;
  // human can use "ドロー" cards manually. We do not auto-exile human cards.
  if(player===state.ai) {
    aiCompression(player);
  }
}

function aiCompression(p) {
  // AI publicly exiles low-value cards to draw 2 each.
  let count=0;
  while(p.hand.length>0 && count<2) {
    const candidate = p.hand
      .filter(c=>c.id!=="strong_attack" && c.id!=="strong_defense" && c.id!=="counterattack" && c.id!=="life_reuse")
      .sort((a,b)=>cardValue(a)-cardValue(b))[0];
    if(!candidate) break;
    publicExile(p,candidate);
    count++;
    draw(p,2);
    log(`AI が ${candidate.name} を公開除外し、2枚ドロー。`);
  }
}

function cardValue(c) {
  const v={
    basic_attack:6, strong_attack:9, basic_defense:5, strong_defense:8,
    dodge:7, hand_reaction:5, counterattack:9, draw:8, life_reuse:10, reconstruct:6
  };
  return v[c.id] ?? 5;
}

function useCard(player, card, target=null) {
  const i=player.hand.indexOf(card);
  if(i<0) return false;

  // Cost validation
  if(card.exileCost && player.hand.length-1 < card.exileCost) return false;
  if(card.handCost && player.hand.length-1 < card.handCost) return false;
  if(card.id==="life_reuse" && player.life<=4) return false;
  if(card.id==="reconstruct" && player.deck.length>10) return false;

  player.hand.splice(i,1);

  if(card.exileCost) {
    for(let n=0;n<card.exileCost;n++) {
      const cost = chooseCostCard(player);
      if(!cost) return false;
      publicExile(player,cost);
    }
  }

  if(card.handCost) {
    for(let n=0;n<card.handCost;n++) {
      const cost = chooseCostCard(player);
      if(!cost) return false;
      publicExile(player,cost);
    }
  }

  if(card.id==="draw") {
    publicExile(player,card);
    draw(player,2);
    log(`${player.name}：ドロー → 2枚引く。`);
    return true;
  }

  if(card.id==="life_reuse") {
    player.life-=4;
    publicExile(player,card);
    // Prototype: only publicly exiled cards can be recovered.
    if(player.publicExile.length>1) {
      const candidates=player.publicExile.filter(c=>c.uid!==card.uid);
      const recovered=candidates[Math.floor(Math.random()*candidates.length)];
      const idx=player.publicExile.indexOf(recovered);
      player.publicExile.splice(idx,1);
      player.hand.push(recovered);
      log(`${player.name}：命の再利用 → ${recovered.name} を手札へ。`);
    } else log(`${player.name}：命の再利用 → 回収対象なし。`);
    return true;
  }

  if(card.id==="reconstruct") {
    publicExile(player,card);
    rebuild(player);
    log(`${player.name}：再構築。`);
    return true;
  }

  if(card.type==="attack") {
    publicExile(player,card);
    player.pendingAttack={card, damage:card.damage};
    log(`${player.name}：${card.name}。${card.damage}ダメージを宣言。`);
    return true;
  }

  if(card.id==="dodge") {
    publicExile(player,card);
    player.dodge=true;
    log(`${player.name}：回避。次に受けるダメージを半減。`);
    return true;
  }

  if(card.id==="hand_reaction") {
    publicExile(player,card);
    publicExile(player, chooseCostCard(player));
    publicExile(player, chooseCostCard(player));
    player.pendingDirectDamage=(player.pendingDirectDamage||0)+3;
    log(`${player.name}：手札反応。相手へ3ダメージ。`);
    return true;
  }

  if(card.id==="counterattack") {
    publicExile(player,card);
    publicExile(player, chooseCostCard(player));
    publicExile(player, chooseCostCard(player));
    player.counter=true;
    log(`${player.name}：反撃。相手のカード使用ごとに3ダメージ。`);
    return true;
  }

  return true;
}

function chooseCostCard(player) {
  if(player.hand.length===0) return null;
  return [...player.hand].sort((a,b)=>cardValue(a)-cardValue(b))[0];
}

function dealDamage(target, amount) {
  if(target.dodge) {
    amount=Math.ceil(amount/2);
    target.dodge=false;
  }
  target.life-=amount;
  log(`${target.name} に ${amount}ダメージ。`);
}

function resolveAttack(attacker, defender) {
  const attack=attacker.pendingAttack;
  if(!attack) return;

  // AI/basic prototype defense decision.
  if(defender===state.ai) aiDefend(defender, attack);
  else humanDefense(defender, attack);

  attacker.pendingAttack=null;
}

function humanDefense(defender, attack) {
  const defenses=defender.hand.filter(c=>c.type==="defense");
  if(defenses.length===0) {
    dealDamage(defender,attack.damage);
    return;
  }
  const msg=`攻撃 ${attack.damage}。防御カードを使いますか？`;
  if(confirm(msg)) {
    const card=defenses.sort((a,b)=>(b.defense||0)-(a.defense||0))[0];
    useCard(defender,card);
    const remaining=Math.max(0,attack.damage-(card.defense||0));
    if(remaining) dealDamage(defender,remaining);
    else log(`${defender.name}：完全防御。`);
  } else dealDamage(defender,attack.damage);
}

function aiDefend(defender, attack) {
  const defenses=defender.hand.filter(c=>c.type==="defense");
  const strong=defenses.find(c=>c.id==="strong_defense");
  const basic=defenses.find(c=>c.id==="basic_defense");
  let card=null;

  if(strong && attack.damage>=7) card=strong;
  else if(basic && attack.damage>=5) card=basic;

  if(card) {
    useCard(defender,card);
    const remaining=Math.max(0,attack.damage-(card.defense||0));
    if(remaining) dealDamage(defender,remaining);
    else log(`AI：${card.name} で完全防御。`);
  } else dealDamage(defender,attack.damage);
}

function aiTurn() {
  const p=state.ai;
  startTurn(p);

  // Simple priority: lethal attack > attack > defense/utility.
  const lethal=p.hand.find(c=>c.type==="attack" && c.damage>=p.opponent.life);
  const attack=p.hand.find(c=>c.id==="strong_attack") || p.hand.find(c=>c.id==="basic_attack");

  if(lethal) {
    useCard(p,lethal);
    resolveAttack(p,state.player);
  } else if(attack) {
    useCard(p,attack);
    resolveAttack(p,state.player);
  } else {
    const utility=p.hand.find(c=>["draw","reconstruct"].includes(c.id) && (c.id!=="reconstruct" || p.deck.length<=10));
    if(utility) useCard(p,utility);
  }

  if(p.counter && state.player) {
    // Counterattack is cleared at the end of the turn.
  }
  endTurn(state.ai);
}

function endTurn(player) {
  if(player.counter) {
    player.counter=false;
    log(`${player.name}：反撃の効果終了。`);
  }
  state.turn++;
  if(state.player.life<=0 || state.ai.life<=0) {
    log(state.player.life<=0 ? "AIの勝利。" : "あなたの勝利。");
    disableGame();
    return;
  }

  if(player===state.player) {
    state.current="ai";
    aiTurn();
    state.current="player";
    startTurn(state.player);
  }
  render();
}

function disableGame() {
  document.querySelectorAll("#hand button").forEach(b=>b.disabled=true);
}

function playHumanCard(card) {
  if(state.current!=="player") return;

  // Counterattack on opponent's card use.
  if(state.ai.counter) {
    state.ai.counter=false; // one resolution cycle in prototype
    dealDamage(state.player,3);
    log("AIの反撃：あなたのカード使用により3ダメージ。");
  }

  if(card.type==="attack") {
    useCard(state.player,card);
    resolveAttack(state.player,state.ai);
  } else {
    useCard(state.player,card);
  }
  render();
}

function render() {
  document.querySelector("#pLife").textContent=state.player.life;
  document.querySelector("#aLife").textContent=state.ai.life;
  document.querySelector("#pHand").textContent=state.player.hand.length;
  document.querySelector("#aHand").textContent=state.ai.hand.length;
  document.querySelector("#deck").textContent=state.player.deck.length;
  document.querySelector("#grave").textContent=state.player.grave.length;
  document.querySelector("#publicExile").textContent=state.player.publicExile.length;
  document.querySelector("#rebuilds").textContent=state.player.rebuilds;

  const hand=document.querySelector("#hand");
  hand.innerHTML="";
  state.player.hand.forEach(card=>{
    const b=document.createElement("button");
    b.innerHTML=`<b>${card.name}</b><br><span class="small">${card.text}</span>`;
    b.onclick=()=>playHumanCard(card);
    hand.appendChild(b);
  });
}

function newGame() {
  const deck=makeDeck();
  state={
    turn:1,current:"player",
    player:{name:"あなた",life:30,deck:deck.splice(0),hand:[],grave:[],publicExile:[],hiddenExile:[],rebuilds:0,dodge:false,counter:false},
    ai:{name:"AI",life:30,deck:[],hand:[],grave:[],publicExile:[],hiddenExile:[],rebuilds:0,dodge:false,counter:false}
  };

  // Deal from one shuffled 80-card pool.
  state.ai.deck=state.player.deck.splice(0);
  draw(state.player,8);
  draw(state.ai,8);
  startTurn(state.player);
  log("ゲーム開始。");
  render();
}

document.querySelector("#newGame").onclick=newGame;
document.querySelector("#endTurn").onclick=()=>{
  if(state.current==="player") endTurn(state.player);
};

newGame();
